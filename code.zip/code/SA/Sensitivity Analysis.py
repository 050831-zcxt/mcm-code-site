import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import ListedColormap

plt.rcParams.update({
    "font.size": 18,
    "axes.titlesize": 20,
    "axes.labelsize": 18,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "legend.fontsize": 16,
    "font.family": "DejaVu Serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": False,
})

# =============================
# 0) File path
# =============================
PARAM_XLSX = "参数.xlsx"

# =============================
# 1) Load & parse parameters
# =============================
params_df = pd.read_excel(PARAM_XLSX, sheet_name="Parameters")

range_pat = re.compile(r"(?P<a>\d*\.?\d+(?:[eE][-+]?\d+)?)\s*-\s*(?P<b>\d*\.?\d+(?:[eE][-+]?\d+)?)")
num_pat   = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")

def strip_paren(s: str) -> str:
    """Remove the first '(' and everything after it."""
    if s is None:
        return s
    i = s.find("(")
    return s[:i].rstrip() if i != -1 else s

def parse_numeric_or_range(val):
    """Parse scalar number or range like '100–150' / '100-150'."""
    if pd.isna(val):
        return None
    if isinstance(val, (int, float, np.integer, np.floating)):
        return float(val)
    s = str(val).strip().replace("–", "-").replace("—", "-").replace("−", "-")
    m = range_pat.search(s)
    if m:
        a = float(m.group("a")); b = float(m.group("b"))
        return (min(a, b), max(a, b))
    m2 = num_pat.search(s)
    if m2:
        return float(m2.group(0))
    return None

def mid(v):
    return (v[0] + v[1]) / 2 if isinstance(v, tuple) else v

# raw values/ranges + metadata
p_raw = {}
meta  = {}
for _, row in params_df.iterrows():
    sym = row.get("Symbol")
    val = parse_numeric_or_range(row.get("Value"))
    if sym is None or pd.isna(sym) or val is None:
        continue
    sym = str(sym).strip()
    p_raw[sym] = val
    meta[sym] = {
        "Parameter": row.get("Parameter"),
        "Unit": row.get("Unit"),
        "Category": row.get("Category"),
    }

# baseline (midpoint for ranges)
p_base = {k: mid(v) for k, v in p_raw.items()}
# if rocket payload is a range, use the high-end (e.g., 150 t/launch)
if isinstance(p_raw.get("m_payload_rocket"), tuple):
    p_base["m_payload_rocket"] = p_raw["m_payload_rocket"][1]

def nice_label(sym, max_len=46):
    """Axis label from Excel: Parameter (Unit)."""
    name = meta.get(sym, {}).get("Parameter", None)
    unit = meta.get(sym, {}).get("Unit", None)

    if name is None or (isinstance(name, float) and np.isnan(name)):
        s = sym
    else:
        s = str(name).strip()
        if unit and not (isinstance(unit, float) and np.isnan(unit)):
            u = str(unit).strip()
            if u:
                s = f"{s} ({u})"
    if len(s) > max_len:
        s = s[:max_len-1] + "…"
    return s

# Scenario knobs (fixed during bivariate plots)
scenario_base = {"N_sites": 10.0, "launches_per_site_per_day": 1.0, "CI_grid": 0.40}

# =============================
# 2) Model evaluation
# =============================
def eval_outputs(p, N_sites=10, launches_per_site_per_day=1.0, CI_grid=0.40, rocket_fuel="ch4"):
    # total mission mass
    M_const_t = float(p["M_const"])     # tonnes
    M_kg      = M_const_t * 1000.0

    # capacities
    C_elev_tyr = float(p["C_elev"])              # t/yr
    payload_t  = float(p["m_payload_rocket"])    # t/launch

    L_year     = float(N_sites) * float(launches_per_site_per_day) * 365.0
    C_rock_tyr = payload_t * L_year

    # times
    T_e = M_const_t / C_elev_tyr
    T_r = M_const_t / C_rock_tyr
    T_h = M_const_t / (C_elev_tyr + C_rock_tyr)

    # hybrid mass split
    M_elev_h_kg = C_elev_tyr * T_h * 1000.0
    M_rock_h_kg = M_kg - M_elev_h_kg

    # ---- Cost model ----
    op_usd_lb = float(p.get("OpEx_elev_unit", 100.0))
    op_usd_kg = op_usd_lb * 2.2046226218

    capex_bil = float(p.get("CapEx_elev_total", 0.0))  # Billion USD
    capex_usd = capex_bil * 1e9

    cost_elev_only = capex_usd + op_usd_kg * M_kg
    cost_hybrid_e  = capex_usd + op_usd_kg * M_elev_h_kg

    # rocket cost to LEO: interpolate between 20/yr and 200/yr benchmarks
    c20  = float(p.get("c_LEO_reuse_20", 1663.0))
    c200 = float(p.get("c_LEO_reuse_200", 756.0))
    if L_year <= 20:
        c_leo = c20
    elif L_year >= 200:
        c_leo = c200
    else:
        x  = np.log(L_year); x0 = np.log(20.0); x1 = np.log(200.0)
        y0 = np.log(c20);   y1 = np.log(c200)
        c_leo = float(np.exp(y0 + (y1 - y0) * (x - x0) / (x1 - x0)))

    # LEO -> TLI penalty factor (proxy)
    f_TLI = float(p.get("m_LEO_SLS_B1", 95.0)) / float(p.get("m_TLI_SLS_B1", 27.0))
    c_tli = c_leo * f_TLI

    cost_rock_only = c_tli * M_kg
    cost_hybrid_r  = c_tli * M_rock_h_kg
    cost_hybrid    = cost_hybrid_e + cost_hybrid_r

    # ---- Emissions model ----
    e_GEO = float(p.get("e_GEO", 14.8))   # kWh/kg
    co2_elev_only = M_kg * e_GEO * CI_grid
    co2_hybrid_e  = M_elev_h_kg * e_GEO * CI_grid

    mlox = float(p.get("m_LOX_SLS_core", 843.7)) * 1000.0
    mlh2 = float(p.get("m_LH2_SLS_core", 143.8)) * 1000.0
    payload_sls = float(p.get("m_TLI_SLS_B1", 27.0)) * 1000.0
    r_prop = (mlox + mlh2) / payload_sls

    EI = float(p.get("EI_CO2_ch4", 426.0)) if rocket_fuel == "ch4" else float(p.get("EI_CO2_ker", 637.0))
    co2_per_payload = (EI / 1000.0) * r_prop  # kgCO2/kg payload

    co2_rock_only = M_kg * co2_per_payload
    co2_hybrid_r  = M_rock_h_kg * co2_per_payload

    return {
        "T_elevator_only": T_e, "T_rocket_only": T_r, "T_hybrid": T_h,
        "C_elevator_only": cost_elev_only / 1e12, "C_rocket_only": cost_rock_only / 1e12, "C_hybrid": cost_hybrid / 1e12,
        "E_elevator_only": co2_elev_only / 1e9, "E_rocket_only": co2_rock_only / 1e9, "E_hybrid": (co2_hybrid_e + co2_hybrid_r) / 1e9,
        "Rocket_launches_per_year": L_year
    }

# =============================
# 3) Ranges for bivariate sweeps
# =============================
def get_range(sym, base_val, default_pct=0.20):
    raw = p_raw.get(sym, None)
    if isinstance(raw, tuple):
        return float(raw[0]), float(raw[1]), float(base_val)
    lo = float(base_val) * (1 - default_pct)
    hi = float(base_val) * (1 + default_pct)
    if lo <= 0:
        lo = float(base_val) * 0.50
    return lo, hi, float(base_val)

# =============================
# 4) Bivariate grid + auto-expand to make contour exist
# =============================
def bivariate_ratio(sym_x, sym_y, out_key, nx=31, ny=31, rocket_fuel="ch4",
                    x_lo=None, x_hi=None, y_lo=None, y_hi=None):
    base_out = eval_outputs(p_base, **scenario_base, rocket_fuel=rocket_fuel)
    base_val = base_out[out_key]

    x0 = p_base[sym_x]
    y0 = p_base[sym_y]

    if x_lo is None or x_hi is None:
        x_lo0, x_hi0, _ = get_range(sym_x, x0)
        x_lo = x_lo0 if x_lo is None else x_lo
        x_hi = x_hi0 if x_hi is None else x_hi

    if y_lo is None or y_hi is None:
        y_lo0, y_hi0, _ = get_range(sym_y, y0)
        y_lo = y_lo0 if y_lo is None else y_lo
        y_hi = y_hi0 if y_hi is None else y_hi

    xs = np.linspace(x_lo, x_hi, nx)
    ys = np.linspace(y_lo, y_hi, ny)

    Z_abs = np.zeros((ny, nx))
    for i, yv in enumerate(ys):
        for j, xv in enumerate(xs):
            p_tmp = dict(p_base)
            p_tmp[sym_x] = float(xv)
            p_tmp[sym_y] = float(yv)
            out = eval_outputs(p_tmp, **scenario_base, rocket_fuel=rocket_fuel)
            Z_abs[i, j] = out[out_key]

    Z_ratio = Z_abs / base_val
    return xs, ys, Z_abs, Z_ratio, base_val

def ensure_contour_exists(sym_x, sym_y, out_key, target_year,
                          nx=31, ny=31, rocket_fuel="ch4",
                          max_expand_steps=6, expand_factor=1.25):
    """
    If target_year is not within [min, max] of the grid, expand the HIGH bounds
    (for time, higher capacities reduce time -> helps reach smaller targets like 110).
    """
    x0 = p_base[sym_x]
    y0 = p_base[sym_y]
    x_lo, x_hi, _ = get_range(sym_x, x0)
    y_lo, y_hi, _ = get_range(sym_y, y0)

    for step in range(max_expand_steps + 1):
        xs, ys, Z_abs, Z_ratio, base_val = bivariate_ratio(
            sym_x, sym_y, out_key, nx=nx, ny=ny, rocket_fuel=rocket_fuel,
            x_lo=x_lo, x_hi=x_hi, y_lo=y_lo, y_hi=y_hi
        )
        tmin, tmax = float(Z_abs.min()), float(Z_abs.max())
        if tmin <= target_year <= tmax:
            return xs, ys, Z_abs, Z_ratio, base_val, (x_lo, x_hi, y_lo, y_hi), True

        # If target is smaller than any value (common for 110), expand HIGH bounds
        if target_year < tmin:
            x_hi *= expand_factor
            y_hi *= expand_factor
        # If target is larger than any value, expand LOW bounds downward
        elif target_year > tmax:
            x_lo /= expand_factor
            y_lo /= expand_factor

    return xs, ys, Z_abs, Z_ratio, base_val, (x_lo, x_hi, y_lo, y_hi), False

def plot_heatmap_ratio_with_contour(xs, ys, Z_ratio, Z_abs,
                                    sym_x, sym_y,
                                    title, cbar_label="Output / Baseline",
                                    contour_year=110.0,
                                    cmap="YlGnBu"):
    fig = plt.figure(figsize=(9.2, 6.6))
    ax = plt.gca()

    im = ax.imshow(
        Z_ratio, origin="lower", aspect="auto", interpolation="nearest",
        extent=[xs.min(), xs.max(), ys.min(), ys.max()],
        cmap=cmap
    )

    # draw contour if possible
    tmin, tmax = float(Z_abs.min()), float(Z_abs.max())
    if tmin <= contour_year <= tmax:
        cs = ax.contour(xs, ys, Z_abs, levels=[contour_year], colors="k", linewidths=1.4, alpha=0.80)
        ax.clabel(cs, inline=True, fontsize=12, fmt=lambda v: f"{v:.0f} yr")
    else:
        ax.text(
            0.02, 0.02,
            f"Contour {contour_year:.0f} yr not reachable\nin current range ({tmin:.1f}–{tmax:.1f} yr)",
            transform=ax.transAxes, fontsize=12,
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="0.7")
        )

    ax.set_title(title, pad=10)
    ax.set_xlabel(strip_paren(nice_label(sym_x)))
    ax.set_ylabel(strip_paren(nice_label(sym_y)))

    cbar = plt.colorbar(im, ax=ax, fraction=0.036, pad=0.03)
    cbar.set_label(cbar_label)

    plt.tight_layout()
    plt.show()

def plot_heatmap_ratio_cost(xs, ys, Z_ratio, sym_x, sym_y,
                            title, cbar_label="Output / Baseline"):
    base_cmap = cm.get_cmap("YlOrBr")
    warm_muted = ListedColormap(base_cmap(np.linspace(0.25, 0.95, 256)))

    vmin, vmax = np.quantile(Z_ratio, [0.02, 0.98])

    plt.figure(figsize=(9.2, 6.6))
    ax = plt.gca()
    im = ax.imshow(
        Z_ratio,
        origin="lower", aspect="auto", interpolation="nearest",
        extent=[xs.min(), xs.max(), ys.min(), ys.max()],
        cmap=warm_muted,
        vmin=vmin, vmax=vmax
    )

    ax.set_title(title, pad=10)
    ax.set_xlabel(strip_paren(nice_label(sym_x)))
    ax.set_ylabel(strip_paren(nice_label(sym_y)))

    cbar = plt.colorbar(im, ax=ax, fraction=0.036, pad=0.03)
    cbar.set_label(cbar_label)

    plt.tight_layout()
    plt.show()

# =============================
# 5) Produce figures
# =============================

# ---- (A) TIME with 110-year contour (auto-expand if needed) ----
target_year = 110.0
xs, ys, Zt_abs, Zt_ratio, T_base, used_ranges, ok = ensure_contour_exists(
    sym_x="m_payload_rocket",
    sym_y="C_elev",
    out_key="T_hybrid",
    target_year=target_year,
    nx=31, ny=31,
    max_expand_steps=6, expand_factor=1.25
)
print("Baseline Hybrid Time (years):", T_base)
print("Time grid range (years):", float(Zt_abs.min()), float(Zt_abs.max()))
print("Used ranges (x_lo, x_hi, y_lo, y_hi):", used_ranges)
print("Contour reachable:", ok)

plot_heatmap_ratio_with_contour(
    xs, ys, Zt_ratio, Zt_abs,
    sym_x="m_payload_rocket",
    sym_y="C_elev",
    title="Bivariate Sensitivity (Relative) — Hybrid Completion Time",
    cbar_label="Time / Baseline time",
    contour_year=target_year
)

# ---- (B) COST heatmap (relative baseline) ----
xs, ys, Zc_abs, Zc_ratio, C_base = bivariate_ratio(
    sym_x="m_TLI_SLS_B1",
    sym_y="c_LEO_reuse_200",
    out_key="C_hybrid",
    nx=31, ny=31
)
print("Baseline Hybrid Cost (trillion USD):", C_base)

plot_heatmap_ratio_cost(
    xs, ys, Zc_ratio,
    sym_x="m_TLI_SLS_B1",
    sym_y="c_LEO_reuse_200",
    title="Bivariate Sensitivity (Relative) — Hybrid Total Cost",
    cbar_label="Cost / Baseline cost"
)
