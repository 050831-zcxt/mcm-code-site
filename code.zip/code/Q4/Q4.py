import pandas as pd
import numpy as np
import math
import re
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import Normalize

# =============================
# 0) Load parameters.xlsx
# =============================
xlsx_path = "参数.xlsx"  # <-- 若不在同目录，改为你的路径
params = pd.read_excel(xlsx_path, sheet_name="Parameters")

def parse_value(v):
    """Parse numeric values that may appear as ranges like '100–150' or strings."""
    if pd.isna(v):
        return np.nan
    if isinstance(v, (int, float, np.integer, np.floating)):
        return float(v)
    s = str(v).strip().replace(",", "")
    s = s.replace("–", "-").replace("—", "-").replace("~", "").replace(">", "").replace("<", "")
    m = re.match(r"^\s*([0-9.]+)\s*-\s*([0-9.]+)\s*$", s)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        return 0.5 * (a + b)  # midpoint
    try:
        return float(s)
    except:
        return np.nan

def get_param(symbol, default=np.nan):
    row = params.loc[params["Symbol"] == symbol]
    if len(row) == 0:
        return default
    return parse_value(row.iloc[0]["Value"])

# =============================
# 1) Core inputs from your Excel
# =============================
# Problem statement
M_const_t = get_param("M_const")                     # metric tons
C_elev_tpy = get_param("C_elev")                     # metric tons/year (system)
m_payload_rocket_t = get_param("m_payload_rocket", 150.0)  # metric tons/launch
m_prop_FH_total_kg = get_param("m_prop_FH_total")          # kg propellant / launch (Falcon Heavy proxy)

# Cost model
OpEx_elev_unit_usd_per_lb = get_param("OpEx_elev_unit", 100.0)  # USD/lb
CapEx_elev_total_busd = get_param("CapEx_elev_total", 10.0)     # Billion USD
c_GEO_elec_usd_per_kg = get_param("c_GEO_elec", 1.48)           # $/kg @ $0.10/kWh (implies kWh/kg)

c_LEO_reuse_20 = get_param("c_LEO_reuse_20", 1663.0)            # USD/kg (early)
c_LEO_reuse_200 = get_param("c_LEO_reuse_200", 756.0)           # USD/kg (mature)
f_lc = get_param("f_lc", 0.9)                                   # learning curve factor

# LEO->Moon penalty proxy from SLS ratio (conservative proxy)
m_LEO_SLS = get_param("m_LEO_SLS_B1", 95.0)
m_TLI_SLS = get_param("m_TLI_SLS_B1", 27.0)
penalty_LEO_to_Moon = (m_LEO_SLS / m_TLI_SLS) if (m_TLI_SLS and not np.isnan(m_TLI_SLS)) else 3.5

# Emission indices (per kg propellant)
EI_CO2_ker = get_param("EI_CO2_ker", 637.0) / 1000.0  # kg CO2 / kg prop
EI_BC_ker  = get_param("EI_BC_ker", 22.0)  / 1000.0   # kg BC  / kg prop
N_port = 1  # baseline: 1 harbor operational (to be consistent with Q1 table)

# =============================
# 2) Assumptions (explicit & editable)
#    — these are the only "modeling assumptions" not directly in Excel.
# =============================
price_per_kwh = 0.10  # consistent with how c_GEO_elec is defined
kwh_per_kg_elev = c_GEO_elec_usd_per_kg / price_per_kwh  # implied kWh/kg

grid_I0 = 0.40      # kg CO2/kWh (baseline grid intensity at 2050)
decarb_k = 0.03     # 1/year (exponential decarbonization rate), 2050->2150 cleaner
year0 = 2050

# Stratospheric sensitivity weighting (per your Problem 4 notes)
f_high_alt = 0.20   # fraction of propellant "high-alt" (simplified)
s_strat = 3.0       # high-alt sensitivity multiplier
GWP_BC = 900.0      # BC -> CO2e factor (order-of-magnitude representative)

# Rocket cadence limit (aggregated over multiple sites)
L_max_per_year = 5000

# =============================
# 3) Units & conversions
# =============================
KG_PER_TONNE = 1000.0
LB_PER_KG = 2.2046226218

M_total_kg = M_const_t * KG_PER_TONNE
C_elev_per_port_kgpy = C_elev_tpy * 1000
C_elev_kgpy = N_port * C_elev_per_port_kgpy *3
payload_kg = m_payload_rocket_t * KG_PER_TONNE

OpEx_elev_usd_per_kg = OpEx_elev_unit_usd_per_lb * LB_PER_KG
CapEx_elev_usd = CapEx_elev_total_busd * 1e9

# Wright's law exponent: if cumulative doubles, cost multiplies by f_lc
b_wright = math.log(f_lc) / math.log(2)  # negative if learning occurs

# =============================
# 4) Environment & cost evaluators
# =============================
def label_bars(ax, bars, fmt="{:.2f}", pad=3, fontsize=10):
    """
    ax: matplotlib axis
    bars: ax.bar(...) 返回的 BarContainer
    fmt: 数值格式，如 "{:.0f}" "{:.2f}"
    pad: 标签离柱顶的像素距离
    """
    for b in bars:
        h = b.get_height()
        if np.isnan(h):
            continue
        ax.annotate(
            fmt.format(h),
            (b.get_x() + b.get_width() / 2, h),
            xytext=(0, pad),
            textcoords="offset points",
            ha="center",
            va="bottom",
            fontsize=fontsize
        )

def avg_grid_intensity_over_T(T):
    """
    Average of I0*exp(-k*t) over t in [0, T).
    """
    if T <= 0:
        return grid_I0
    return grid_I0 * (1 - math.exp(-decarb_k * T)) / (decarb_k * T)

def elevator_cost_usd(mass_kg):
    return CapEx_elev_usd + OpEx_elev_usd_per_kg * mass_kg

def elevator_env_co2e_kg(mass_kg, T):
    kwh = mass_kg * kwh_per_kg_elev
    return kwh * avg_grid_intensity_over_T(T)

def rocket_env_co2e_kg(num_launches):
    """
    CO2e = CO2 + weighted BC (higher for high-alt fraction).
    """
    if num_launches <= 0:
        return 0.0
    prop = m_prop_FH_total_kg * num_launches
    co2 = prop * EI_CO2_ker
    bc  = prop * EI_BC_ker
    bc_co2e = ((1 - f_high_alt) * bc * GWP_BC + f_high_alt * bc * GWP_BC * s_strat)
    return co2 + bc_co2e

def rocket_cost_usd(num_launches):
    """
    Aggregate rocket cost without summing per-launch (N can be huge).
    per-kg to LEO: c(n)=max(c_mature, c0*n^b), then * penalty to Moon.
    total = payload_kg * sum_{n=1..N} c_moon(n), approximated by integral + plateau.
    """
    N = int(num_launches)
    if N <= 0:
        return 0.0

    c0 = c_LEO_reuse_20
    c_min = c_LEO_reuse_200

    # N* where c0*(N*)^b = c_min
    if abs(b_wright) < 1e-12:
        N_star = 1.0
    else:
        N_star = (c_min / c0) ** (1.0 / b_wright)
    N_star = max(1.0, float(N_star))

    def integral_pow(n1, n2, b):
        # ∫ n^b dn
        if abs(b + 1) < 1e-12:
            return math.log(n2 / n1)
        return (n2 ** (b + 1) - n1 ** (b + 1)) / (b + 1)

    if N <= N_star:
        sum_c_leo = c0 * integral_pow(1.0, N + 1.0, b_wright)
    else:
        sum_c_leo = c0 * integral_pow(1.0, N_star, b_wright) + c_min * (N - N_star + 1)

    sum_c_moon = sum_c_leo * penalty_LEO_to_Moon
    return payload_kg * sum_c_moon

def evaluate_plan(T, rocket_fraction):
    """
    Decision variables:
      T (years), rocket_fraction r in [0,1]
    Constraints:
      elevator mass <= C_elev*T
      rocket launches <= L_max_per_year*T
    Objectives: minimize cost, time, env.
    """
    T = int(T)
    if T <= 0:
        return None

    m_rocket = rocket_fraction * M_total_kg
    m_elev = M_total_kg - m_rocket

    # elevator capacity constraint
    if m_elev > C_elev_kgpy * T + 1e-9:
        return None

    launches = int(math.ceil(m_rocket / payload_kg)) if m_rocket > 0 else 0
    if launches > L_max_per_year * T:
        return None

    cost = rocket_cost_usd(launches) + elevator_cost_usd(m_elev)
    env = rocket_env_co2e_kg(launches) + elevator_env_co2e_kg(m_elev, T)

    return dict(T=T, r=rocket_fraction, launches=launches,
                m_rocket=m_rocket, m_elev=m_elev,
                cost=cost, env=env)

# =============================
# 5) Pareto set (3-objective nondominated)
# =============================
rng = np.random.default_rng(1)
cands = []
for _ in range(30000):
    T = int(rng.integers(20, 350))
    r = float(rng.random())
    out = evaluate_plan(T, r)
    if out is not None:
        cands.append(out)

arr = np.array([[c["cost"], c["T"], c["env"]] for c in cands], dtype=float)

def is_dominated(i):
    v = arr[i]
    dom = np.all(arr <= v, axis=1) & np.any(arr < v, axis=1)
    return dom.any()

keep = np.array([not is_dominated(i) for i in range(len(cands))], dtype=bool)
pareto = [cands[i] for i in range(len(cands)) if keep[i]]
pareto_arr = np.array([[p["cost"], p["T"], p["env"]] for p in pareto], dtype=float)

# knee: closest to ideal after normalization
mins, maxs = pareto_arr.min(axis=0), pareto_arr.max(axis=0)
norm = (pareto_arr - mins) / (maxs - mins + 1e-12)
dist = np.linalg.norm(norm, axis=1)
knee = pareto[int(dist.argmin())]
pareto_df = pd.DataFrame({
    "time_years": [p["T"] for p in pareto],
    "cost_trillion": [p["cost"]/1e12 for p in pareto],
    "env_mt": [p["env"]/1e9 for p in pareto],
    "rocket_share": [p["r"] for p in pareto],
})
pareto_df["is_knee"] = 0
pareto_df.loc[int(dist.argmin()), "is_knee"] = 1
pareto_df.to_csv("pareto_points.csv", index=False)
print("Saved pareto_points.csv")

# =============================
# 6) Baseline scenarios
# =============================
# A) Elevator only
T_elev_only = int(math.ceil(M_total_kg / C_elev_kgpy))
A = evaluate_plan(T_elev_only, 0.0)

# B) Rockets only (time-min by max cadence)
launches_total = int(math.ceil(M_total_kg / payload_kg))
T_rocket_only = int(math.ceil(launches_total / L_max_per_year))
B = evaluate_plan(T_rocket_only, 1.0)

# C) Hybrid knee
C = knee

# =============================
# 7) Print results table
# =============================
def usd_to_trillion(x): return x / 1e12
def kg_to_Mt(x): return x / 1e9

results = pd.DataFrame([
    ["Elevator only", A["T"], A["launches"], kg_to_Mt(A["m_elev"]), kg_to_Mt(A["m_rocket"]), usd_to_trillion(A["cost"]), kg_to_Mt(A["env"])],
    ["Rockets only",  B["T"], B["launches"], kg_to_Mt(B["m_elev"]), kg_to_Mt(B["m_rocket"]), usd_to_trillion(B["cost"]), kg_to_Mt(B["env"])],
    ["Hybrid (Pareto knee)", C["T"], C["launches"], kg_to_Mt(C["m_elev"]), kg_to_Mt(C["m_rocket"]), usd_to_trillion(C["cost"]), kg_to_Mt(C["env"])],
], columns=["Scenario", "Time (years)", "Total launches",
            "Elevator mass (Mt)", "Rocket mass (Mt)",
            "Total cost (trillion USD)", "Env impact (Mt CO2e)"])

print("\n=== Problem 4 Results (3 scenarios) ===")
print(results.to_string(index=False))

print("\n=== Recommended Hybrid (Pareto knee) ===")
print(f"T = {C['T']} years")
print(f"Rocket share = {C['r']:.3f}, Elevator share = {1-C['r']:.3f}")
print(f"Total rocket launches = {C['launches']}")
print(f"Total cost = {usd_to_trillion(C['cost']):.3f} trillion USD")
print(f"Environmental impact = {kg_to_Mt(C['env']):.3f} Mt CO2e")

# =============================
# 8) Publication-ready plots (serif + pastel)
# =============================
mpl.rcParams.update({
    "font.family": "DejaVu Serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linestyle": "--",
    "grid.alpha": 0.25,
    "figure.dpi": 160,
})

BLUE = "#4C78A8"
GRAY = "#9E9E9E"
ACCENT = "#72B7B2"
ORANGE = "#F2A65A"

# Figure 1: scenario comparison
mpl.rcParams.update({
    "font.family": "DejaVu Serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linestyle": "--",
    "grid.alpha": 0.25,
    "figure.dpi": 160,
})

GRAY   = "#9E9E9E"
BLUE   = "#4C78A8"
ACCENT = "#72B7B2"

def label_bars(ax, bars, fmt="{:.2f}", pad=3, fontsize=10):
    for b in bars:
        h = b.get_height()
        ax.annotate(fmt.format(h),
                    (b.get_x() + b.get_width()/2, h),
                    xytext=(0, pad),
                    textcoords="offset points",
                    ha="center", va="bottom",
                    fontsize=fontsize)

# ===== data =====
scenarios = results["Scenario"].tolist()
colors = [GRAY, BLUE, ACCENT]

fig, axes = plt.subplots(1, 3, figsize=(13.2, 3.8), constrained_layout=False)

# 关键：手动留出左边空间，避免左侧 y-label 被裁
fig.subplots_adjust(left=0.04, right=0.93, bottom=0.28, top=0.88, wspace=0.32)

# --- Timeline ---
bars0 = axes[0].bar(scenarios, results["Time (years)"], color=colors, alpha=0.85)
axes[0].set_ylabel("Time (years)", labelpad=12)  # labelpad 再增加可读性
axes[0].set_title("Timeline")
axes[0].tick_params(axis="x", rotation=25, labelsize=10)
label_bars(axes[0], bars0, fmt="{:.0f}", pad=3, fontsize=11)

# --- Cost ---
bars1 = axes[1].bar(scenarios, results["Total cost (trillion USD)"], color=colors, alpha=0.85)
axes[1].set_ylabel("Total cost (trillion USD)", labelpad=12)
axes[1].set_title("Cost")
axes[1].tick_params(axis="x", rotation=25, labelsize=10)
label_bars(axes[1], bars1, fmt="{:.2f}", pad=3, fontsize=11)

# --- Environment ---
bars2 = axes[2].bar(scenarios, results["Env impact (Mt CO2e)"], color=colors, alpha=0.85)
axes[2].set_ylabel("Environmental impact (Mt CO2e)", labelpad=12)
axes[2].set_title("Environment")
axes[2].tick_params(axis="x", rotation=25, labelsize=10)
label_bars(axes[2], bars2, fmt="{:,.0f}", pad=3, fontsize=11)

# 让 x 轴留一点点空间，避免标签贴边
for ax in axes:
    ax.margins(x=0.06)

# 如果你还想要总标题（可选）
# fig.suptitle("Scenario Comparison (Problem 4)", fontsize=14)

plt.show()


# Figure 2: Pareto (cost-time) colored by environment
pareto_cost = pareto_arr[:, 0] / 1e12
pareto_time = pareto_arr[:, 1]
pareto_env  = pareto_arr[:, 2] / 1e9

fig = plt.figure(figsize=(6.8, 4.7))
ax = plt.gca()

norm_env = Normalize(vmin=np.percentile(pareto_env, 5),
                     vmax=np.percentile(pareto_env, 95))

sc = ax.scatter(pareto_time, pareto_cost, c=pareto_env,
                cmap="viridis", s=28, alpha=0.9,
                edgecolor="none", norm=norm_env)

ax.scatter([C["T"]], [C["cost"]/1e12], s=120,
           color=ORANGE, edgecolor="white",
           linewidth=1.0, zorder=5)

ax.annotate("Pareto knee\n(recommended)",
            xy=(C["T"], C["cost"]/1e12),
            xytext=(C["T"]+15, C["cost"]/1e12*1.05),
            arrowprops=dict(arrowstyle="->", lw=1.0, color=ORANGE),
            fontsize=10)

ax.set_xlabel("Time (years)")
ax.set_ylabel("Total cost (trillion USD)")
ax.set_title("Cost–Time Trade-off (Pareto-optimal set)")

cbar = plt.colorbar(sc, ax=ax, pad=0.02)
cbar.set_label("Environmental impact (Mt CO2e)")

# soft background bands
ax.axvspan(0, 200, alpha=0.06, color=GRAY)
ax.axvspan(200, 350, alpha=0.06, color=BLUE)
ax.text(40, ax.get_ylim()[0] + 0.02*(ax.get_ylim()[1]-ax.get_ylim()[0]),
        "Aggressive timeline\n(high rocket cadence)", fontsize=9, color="#555555")
ax.text(235, ax.get_ylim()[0] + 0.02*(ax.get_ylim()[1]-ax.get_ylim()[0]),
        "Balanced region", fontsize=9, color="#555555")

plt.tight_layout()
plt.show()

# Figure 3: composition vs objectives
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# ======== Style (keep consistent with your previous settings) ========
mpl.rcParams.update({
    "font.family": "DejaVu Serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linestyle": "--",
    "grid.alpha": 0.25,
    "figure.dpi": 160,
})

# Palette (soft)
BLUE   = "#4C78A8"
ACCENT = "#72B7B2"
ORANGE = "#F2A65A"

# ------------------------------------------------------------
# Figure 3: Pareto set — Rocket share vs (Time, Environment)
#   Fix: y-label clipped + shorten x-axis length
# ------------------------------------------------------------
r_vals   = np.array([p["r"] for p in pareto], dtype=float)
t_vals   = np.array([p["T"] for p in pareto], dtype=float)
env_vals = np.array([p["env"]/1e9 for p in pareto], dtype=float)  # Mt CO2e

# 自动缩短横轴：按数据最大值加一点余量（避免到 1.0 造成空白）
x_max = min(1.0, float(r_vals.max() + 0.08))
x_min = -0.02

fig, axes = plt.subplots(1, 2, figsize=(12.6, 4.2), constrained_layout=False)

# 关键：给左侧留足空间，避免 y-label 被裁掉
# 也适当调大子图间距，防止右图 y-label/标题拥挤
fig.subplots_adjust(left=0.10, right=0.98, bottom=0.18, top=0.88, wspace=0.28)

# --- Left panel: Rocket share vs Time ---
axes[0].scatter(r_vals, t_vals,
                s=32, color=BLUE, alpha=0.65, edgecolor="none")
axes[0].scatter([C["r"]], [C["T"]],
                s=170, color=ORANGE, edgecolor="white", linewidth=1.0, zorder=5)

axes[0].set_xlabel("Rocket share of total mass")
axes[0].set_ylabel("Time (years)", labelpad=10)  # labelpad helps readability
axes[0].set_title("Pareto set: Rocket share vs Time")
axes[0].set_xlim(x_min, x_max)

# --- Right panel: Rocket share vs Environment ---
axes[1].scatter(r_vals, env_vals,
                s=32, color=ACCENT, alpha=0.65, edgecolor="none")
axes[1].scatter([C["r"]], [C["env"]/1e9],
                s=170, color=ORANGE, edgecolor="white", linewidth=1.0, zorder=5)

axes[1].set_xlabel("Rocket share of total mass")
axes[1].set_ylabel("Environmental impact (Mt CO2e)", labelpad=10)
axes[1].set_title("Pareto set: Rocket share vs Environment")
axes[1].set_xlim(x_min, x_max)

plt.show()

# import matplotlib.pyplot as plt
# import matplotlib as mpl
# from matplotlib.colors import Normalize
# import numpy as np
#
# # =============================
# # 字体与全局样式设置 (调大字体)
# # =============================
# mpl.rcParams.update({
#     "font.family": "DejaVu Serif",
#     "axes.spines.top": False,
#     "axes.spines.right": False,
#     "axes.grid": True,
#     "grid.linestyle": "--",
#     "grid.alpha": 0.25,
#     "figure.dpi": 150,
#     "font.size": 12,  # 基础字体调大
#     "axes.titlesize": 16,  # 标题调大
#     "axes.labelsize": 14,  # 坐标轴标签调大
#     "xtick.labelsize": 12,
#     "ytick.labelsize": 12,
# })
#
# ORANGE = "#F2A65A"
# GRAY = "#9E9E9E"
# BLUE = "#4C78A8"
#
# # 准备绘图数据
# # C 是之前代码中计算出的 Pareto knee
# p_cost = pareto_arr[:, 0] / 1e12
# p_time = pareto_arr[:, 1]
# p_env = pareto_arr[:, 2] / 1e9
#
# k_cost = C["cost"] / 1e12
# k_time = C["T"]
# k_env = C["env"] / 1e9
#
#
# def plot_pareto_custom(x_data, y_data, c_data, x_label, y_label, c_label, title, knee_x, knee_y):
#     fig = plt.figure(figsize=(9, 6))
#     ax = plt.gca()
#
#     # 颜色映射归一化 (剔除极端离群点影响颜色分布)
#     norm = Normalize(vmin=np.percentile(c_data, 2), vmax=np.percentile(c_data, 98))
#
#     sc = ax.scatter(x_data, y_data, c=c_data, cmap="viridis",
#                     s=45, alpha=0.85, edgecolor="none", norm=norm)
#
#     # 突出显示 Knee 点
#     ax.scatter([knee_x], [knee_y], s=180, color=ORANGE,
#                edgecolor="white", linewidth=1.5, zorder=10)
#
#     # 添加标注
#     ax.annotate("Pareto knee\n(recommended)",
#                 xy=(knee_x, knee_y),
#                 xytext=(knee_x + (max(x_data) - min(x_data)) * 0.05, knee_y + (max(y_data) - min(y_data)) * 0.05),
#                 arrowprops=dict(arrowstyle="->", lw=1.5, color=ORANGE),
#                 fontsize=13, fontweight='bold')
#
#     ax.set_xlabel(x_label)
#     ax.set_ylabel(y_label)
#     ax.set_title(title, pad=20)
#
#     # 颜色条
#     cbar = plt.colorbar(sc, ax=ax, pad=0.02)
#     cbar.set_label(c_label, size=13)
#     cbar.ax.tick_params(labelsize=11)
#
#     # 背景区域修饰 (根据 Time 轴判断)
#     if x_label == "Time (years)":
#         ax.axvspan(0, 200, alpha=0.06, color=GRAY)
#         ax.text(min(x_data) + 10, min(y_data), "Aggressive timeline", fontsize=11, color="#666666")
#
#     plt.tight_layout()
#     plt.show()
#
#
# # --- 图 1: 原图风格 (C: Env) ---
# plot_pareto_custom(p_time, p_cost, p_env,
#                    "Time (years)", "Total cost (trillion USD)",
#                    "Environmental impact (Mt CO2e)",
#                    "Pareto Front: Cost vs Time", k_time, k_cost)
#
# # --- 图 2: 新增 (C: Cost) ---
# plot_pareto_custom(p_time, p_env, p_cost,
#                    "Time (years)", "Environmental impact (Mt CO2e)",
#                    "Total cost (trillion USD)",
#                    "Pareto Front: Environment vs Time", k_time, k_env)
#
# # --- 图 3: 新增 (C: Time) ---
# plot_pareto_custom(p_cost, p_env, p_time,
#                    "Total cost (trillion USD)", "Environmental impact (Mt CO2e)",
#                    "Time (years)",
#                    "Pareto Front: Environment vs Cost", k_cost, k_env)

import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.colors import Normalize
import numpy as np

# =============================
# 学术风格全局配置
# =============================
mpl.rcParams.update({
    "font.family": "DejaVu Serif",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.linestyle": "--",
    "grid.alpha": 0.3,
    "font.size": 18,  # 基础字号
    "axes.titlesize": 22,  # 标题字号
    "axes.labelsize": 20,  # 轴标签字号
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "legend.fontsize": 18,
    "figure.dpi": 200  # 高清输出
})

ORANGE_KNEE = "#F2A65A"

# 数据映射 (假设 pareto_arr 和 C 已在前文定义)
p_cost = pareto_arr[:, 0] / 1e12
p_time = pareto_arr[:, 1]
p_env = pareto_arr[:, 2] / 1e9

k_cost = C["cost"] / 1e12
k_time = C["T"]
k_env = C["env"] / 1e9


def plot_single_pareto(x, y, c, kx, ky, xl, yl, cl, title, cmap_name, filename):
    plt.figure(figsize=(12, 8))
    ax = plt.gca()

    # 颜色映射归一化
    norm = Normalize(vmin=np.percentile(c, 2), vmax=np.percentile(c, 98))

    # 绘制散点
    sc = ax.scatter(x, y, c=c, cmap=cmap_name, s=100, alpha=0.8, edgecolors='none', norm=norm)

    # 突出 Pareto Knee
    ax.scatter([kx], [ky], s=400, color=ORANGE_KNEE, edgecolor="white", lw=2.5, zorder=10)

    # 添加标注
    ax.annotate("Pareto knee\n(recommended)", xy=(kx, ky),
                xytext=(kx + (max(x) - min(x)) * 0.08, ky + (max(y) - min(y)) * 0.08),
                arrowprops=dict(arrowstyle="->", lw=2, color=ORANGE_KNEE),
                fontsize=20, fontweight='bold')

    ax.set_xlabel(xl, labelpad=15)
    ax.set_ylabel(yl, labelpad=15)
    ax.set_title(title, pad=30)

    # 颜色条
    cbar = plt.colorbar(sc, ax=ax, pad=0.02)
    cbar.set_label(cl, size=18, labelpad=15)
    cbar.ax.tick_params(labelsize=14)

    plt.tight_layout()
    # plt.savefig(filename, bbox_inches='tight') # 取消注释可保存
    plt.show()


# --- 第一张：Cost vs Time (学术绿) ---
plot_single_pareto(p_time, p_cost, p_env, k_time, k_cost,
                   "Time (years)", "Total cost (trillion USD)",
                   "Environmental impact (Mt CO2e)",
                   "Pareto Front: Cost vs Time", "viridis", "pareto_cost_time.png")

# --- 第二张：Environment vs Time (学术蓝金) ---
plot_single_pareto(p_time, p_env, p_cost, k_time, k_env,
                   "Time (years)", "Environmental impact (Mt CO2e)",
                   "Total cost (trillion USD)",
                   "Pareto Front: Environment vs Time", "cividis", "pareto_env_time.png")

# --- 第三张：Environment vs Cost (学术紫红) ---
plot_single_pareto(p_cost, p_env, p_time, k_cost, k_env,
                   "Total cost (trillion USD)", "Environmental impact (Mt CO2e)",
                   "Time (years)",
                   "Pareto Front: Environment vs Cost", "plasma", "pareto_env_cost.png")