import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# --- 1. 参数设置 ---
M_TOTAL = 1e8  # 目标建设总量：1亿吨
ELEV_ANNUAL_CAP = 179000  # 太空电梯年总运力 (吨/年)
G0 = 9.81
ISP_ROCKET = 380  # 甲烷发动机比冲 (s)

# 轨道 Delta-V (m/s)
DV_LEO_TO_MOON = 5800  # 传统火箭 LEO -> 月表
DV_APEX_TO_MOON = 2600  # 电梯顶点 -> 月表 (捕获+降落)

# 成本参数
C_LEO_START = 750  # 2050年起步 LEO 运费 (USD/kg)
LEARNING_RATE = 0.90  # 学习率 (每产量翻倍成本下降10%)
OPEX_ELEV_BASE = 220  # 太空电梯基准运营成本 (USD/kg to Apex)

# 运力上限 (10个发射场，每天发射，每载荷150吨)
ROCKET_CAP_MAX = 10 * 365 * 150


# --- 2. 核心函数 ---
def mass_ratio(dv):
    """ 计算 N+1 倍系数 """
    return np.exp(dv / (G0 * ISP_ROCKET))


def get_rocket_unit_cost(cum_mass):
    """ 基于学习曲线计算火箭单位成本 """
    c_moon_init = C_LEO_START * mass_ratio(DV_LEO_TO_MOON)
    b = -np.log2(LEARNING_RATE)
    q_ref = 1e6  # 经验积累基准量
    return c_moon_init * (max(cum_mass, q_ref) / q_ref) ** (-b)


# --- 3. 方案模拟 ---
def simulate(mode='hybrid', target_years=150):
    history = []
    cum_mass = 0

    # 预计算混合方案下的火箭分配 (后向填充逻辑)
    if mode == 'hybrid':
        needed_rocket_mass = M_TOTAL - (ELEV_ANNUAL_CAP * target_years)
        rocket_schedule = np.zeros(target_years)
        rem = max(0, needed_rocket_mass)
        for t in range(target_years - 1, -1, -1):
            amount = min(ROCKET_CAP_MAX, rem)
            rocket_schedule[t] = amount
            rem -= amount

    for t in range(1, 1000):  # 模拟年份
        if cum_mass >= M_TOTAL: break

        if mode == 'elevator':
            m_e, m_r = min(ELEV_ANNUAL_CAP, M_TOTAL - cum_mass), 0
        elif mode == 'rocket':
            m_e, m_r = 0, min(ROCKET_CAP_MAX, M_TOTAL - cum_mass)
        else:  # hybrid
            if t > target_years: break
            m_e = ELEV_ANNUAL_CAP
            m_r = rocket_schedule[t - 1]

        # 成本计算
        unit_c_r = get_rocket_unit_cost(cum_mass)
        unit_c_e = OPEX_ELEV_BASE * mass_ratio(DV_APEX_TO_MOON)

        annual_cost = (m_e * unit_c_e + m_r * unit_c_r) * 1000  # 吨转kg
        cum_mass += (m_e + m_r)

        history.append({
            'Year': t, 'Mass_Added': m_e + m_r, 'Cum_Mass': cum_mass,
            'Annual_Cost': annual_cost, 'Unit_Rocket_Cost': unit_c_r
        })
    return pd.DataFrame(history)


# 执行模拟
df_e = simulate('elevator')
df_r = simulate('rocket')
df_h = simulate('hybrid', target_years=140)

# --- 4. 可视化 (淡色系美化) ---
plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文
plt.style.use('ggplot')
fig, axes = plt.subplots(2, 2, figsize=(16, 10), facecolor='#FCFCFC')

# Colors
c1, c2, c3 = '#AEC6CF', '#FFB347', '#77DD77'

# Plot 1: 累计运输量对比
axes[0, 0].plot(df_e['Year'], df_e['Cum_Mass'] / 1e6, label='仅电梯', color=c1, lw=2)
axes[0, 0].plot(df_r['Year'], df_r['Cum_Mass'] / 1e6, label='仅火箭', color=c2, lw=2)
axes[0, 0].plot(df_h['Year'], df_h['Cum_Mass'] / 1e6, label='混合优化', color=c3, lw=3)
axes[0, 0].set_title('各方案累计物资运输量 (百万吨)', fontsize=14)
axes[0, 0].set_xlabel('年份');
axes[0, 0].legend()

# Plot 2: 混合方案年度成本
axes[0, 1].fill_between(df_h['Year'], df_h['Annual_Cost'] / 1e9, color='#B3E5FC', alpha=0.6)
axes[0, 1].plot(df_h['Year'], df_h['Annual_Cost'] / 1e9, color='#0288D1', lw=1.5)
axes[0, 1].set_title('混合方案年度成本 (十亿 USD)', fontsize=14)
axes[0, 1].set_xlabel('年份')

# Plot 3: 学习曲线下的单位成本演变
axes[1, 0].plot(df_h['Year'], df_h['Unit_Rocket_Cost'], color='#FF8A65', label='火箭单位成本')
axes[1, 0].axhline(y=OPEX_ELEV_BASE * mass_ratio(DV_APEX_TO_MOON), color='#4FC3F7', ls='--', label='太空电梯单位成本')
axes[1, 0].set_title('运输单位成本演变 (USD/kg)', fontsize=14)
axes[1, 0].set_xlabel('年份');
axes[1, 0].legend()

# Plot 4: 总工期与总成本汇总
summary = pd.DataFrame({
    '方案': ['仅电梯', '仅火箭', '混合优化'],
    '工期(年)': [df_e['Year'].max(), df_r['Year'].max(), df_h['Year'].max()],
    '总成本(万亿USD)': [df_e['Annual_Cost'].sum() / 1e12, df_r['Annual_Cost'].sum() / 1e12,
                        df_h['Annual_Cost'].sum() / 1e12]
})
axes[1, 1].bar(summary['方案'], summary['工期(年)'], color=[c1, c2, c3], alpha=0.7)
axes[1, 1].set_title('完成1亿吨建设所需总年数', fontsize=14)

plt.tight_layout()
plt.savefig('model_results_q1.png')
summary.to_csv('q1_summary.csv', index=False)