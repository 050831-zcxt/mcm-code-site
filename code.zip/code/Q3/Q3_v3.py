import matplotlib.pyplot as plt
from matplotlib.path import Path
import matplotlib.patches as patches

# =========================
# 0) Global style (paper-like)
# =========================
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "figure.dpi": 300,
})

# =========================
# 1) Data (your confirmed numbers)
# =========================
mass_total_t = 41238  # tons
mass_se = 0.75
mass_rk = 0.25

cost_total_m = 362  # million USD
cost_se_m = 156
cost_rk_m = 206
cost_se = cost_se_m / cost_total_m
cost_rk = cost_rk_m / cost_total_m

# Colors (soft, paper-friendly)
COLOR_SE = "#A8D8EA"   # soft blue
COLOR_RK = "#FAD7A0"   # soft orange
TXT = "#2b2b2b"
TITLE = "#444444"

# =========================
# 2) Helpers
# =========================
def fmt_tons(x):
    return f"{x:,.0f} tons"

def fmt_money_m(x):
    return f"${x:.1f} M"

def draw_flow(ax, x0, x1, y0_top, y0_bot, y1_top, y1_bot, color, alpha=0.85, curve=0.45):
    """
    Draw a smooth Sankey-like ribbon connecting two vertical bars.
    curve: controls how "bulgy" the ribbon is (0.35~0.55 works well)
    """
    dx = x1 - x0
    c1 = x0 + dx * curve
    c2 = x1 - dx * curve

    verts = [
        (x0, y0_top),          # start top
        (c1, y0_top),          # bezier ctrl1
        (c2, y1_top),          # bezier ctrl2
        (x1, y1_top),          # end top
        (x1, y1_bot),          # end bottom
        (c2, y1_bot),          # bezier ctrl3
        (c1, y0_bot),          # bezier ctrl4
        (x0, y0_bot),          # start bottom
        (x0, y0_top),          # close
    ]
    codes = [
        Path.MOVETO,
        Path.CURVE4, Path.CURVE4, Path.CURVE4,
        Path.LINETO,
        Path.CURVE4, Path.CURVE4, Path.CURVE4,
        Path.CLOSEPOLY
    ]
    path = Path(verts, codes)
    patch = patches.PathPatch(path, facecolor=color, edgecolor="none", alpha=alpha, zorder=1)
    ax.add_patch(patch)

def add_block_label(ax, x, y_mid, pct, value_str, fontsize=12):
    ax.text(
        x, y_mid,
        f"{pct:.0f}%\n({value_str})",
        ha="center", va="center",
        color=TXT, fontsize=fontsize, zorder=5
    )

# =========================
# 3) Layout
# =========================
fig, ax = plt.subplots(figsize=(12, 6))

x_left = 0.12
x_right = 0.88
bar_w = 0.10

# y positions: bottom segment then top segment
# Left (mass)
yL_rk_bot = 0.0
yL_rk_top = mass_rk
yL_se_bot = mass_rk
yL_se_top = 1.0

# Right (cost)
yR_rk_bot = 0.0
yR_rk_top = cost_rk
yR_se_bot = cost_rk
yR_se_top = 1.0

# =========================
# 4) Bars
# =========================
# Left bars (Mass)
ax.bar(x_left, mass_rk, width=bar_w, bottom=0, color=COLOR_RK, edgecolor="white", linewidth=1.0, zorder=3)
ax.bar(x_left, mass_se, width=bar_w, bottom=mass_rk, color=COLOR_SE, edgecolor="white", linewidth=1.0, zorder=3)

# Right bars (Cost)
ax.bar(x_right, cost_rk, width=bar_w, bottom=0, color=COLOR_RK, edgecolor="white", linewidth=1.0, zorder=3)
ax.bar(x_right, cost_se, width=bar_w, bottom=cost_rk, color=COLOR_SE, edgecolor="white", linewidth=1.0, zorder=3)

# =========================
# 5) Ribbons (flows)
# =========================
# Space Elevator ribbon: from left-top block to right-top block
draw_flow(ax,
          x_left + bar_w/2, x_right - bar_w/2,
          yL_se_top, yL_se_bot,
          yR_se_top, yR_se_bot,
          COLOR_SE, alpha=0.80, curve=0.48)

# Rocket ribbon: from left-bottom block to right-bottom block
draw_flow(ax,
          x_left + bar_w/2, x_right - bar_w/2,
          yL_rk_top, yL_rk_bot,
          yR_rk_top, yR_rk_bot,
          COLOR_RK, alpha=0.80, curve=0.48)

# =========================
# 6) Titles & labels
# =========================
ax.text(x_left, 1.04, "MASS DISTRIBUTION", ha="center", va="bottom",
        fontsize=14, fontweight="bold", color=TITLE)
ax.text(x_right, 1.04, "COST DISTRIBUTION", ha="center", va="bottom",
        fontsize=14, fontweight="bold", color=TITLE)

# Block annotations (left)
add_block_label(ax, x_left, (yL_se_bot + yL_se_top)/2, mass_se*100, fmt_tons(mass_total_t*mass_se), fontsize=12)
add_block_label(ax, x_left, (yL_rk_bot + yL_rk_top)/2, mass_rk*100, fmt_tons(mass_total_t*mass_rk), fontsize=12)

# Block annotations (right)
add_block_label(ax, x_right, (yR_se_bot + yR_se_top)/2, cost_se*100, fmt_money_m(cost_se_m), fontsize=12)
add_block_label(ax, x_right, (yR_rk_bot + yR_rk_top)/2, cost_rk*100, fmt_money_m(cost_rk_m), fontsize=12)

# Subtitles in the middle (optional, subtle)
ax.text(0.50, 0.96, "Space Elevator (High Volume, Lower Unit Cost)",
        ha="center", va="center", fontsize=10, color="#2c7fb8", alpha=0.85, fontweight="bold")
ax.text(0.50, 0.06, "Rocket Fleet (Low Volume, Higher Unit Cost)",
        ha="center", va="center", fontsize=10, color="#d07a1c", alpha=0.85, fontweight="bold")

# Legend (outside, not covering the plot)
legend_handles = [
    patches.Patch(facecolor=COLOR_SE, edgecolor="none", label="Space Elevator"),
    patches.Patch(facecolor=COLOR_RK, edgecolor="none", label="Rocket Fleet"),
]
ax.legend(handles=legend_handles, loc="upper left", bbox_to_anchor=(1.01, 0.98),
          frameon=True, fontsize=11, borderpad=0.6)

# =========================
# 7) Clean canvas
# =========================
ax.set_xlim(0, 1.05)   # extra room for legend
ax.set_ylim(0, 1.10)
ax.axis("off")

plt.tight_layout()
plt.savefig("Problem3_Sankey_Optimized.png", bbox_inches="tight")
plt.show()
