# -*- coding: utf-8 -*-
"""
Problem 2 (Q2): System reliability + Monte Carlo simulation
- Implements 2.1 Reliability Modeling of Subsystems
- Implements 2.2 Monte Carlo Simulation Framework
- Generates publication-ready pastel figures (O-paper friendly)

Input: 参数.xlsx (preferred)
Output: outputs/*.csv, outputs/*.png
"""

from __future__ import annotations

import os
import re
import math
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# =========================
# 0) Paths & Global Config
# =========================
EXCEL_PATH = "参数.xlsx"   # change if needed
OUT_DIR = "outputs"
os.makedirs(OUT_DIR, exist_ok=True)

RNG_SEED = 42
N_SIM = 10000  # 10k is standard for stable CI; reduce if your laptop is slow
MAX_YEARS = 5000  # safety cap (should never hit if plan is sensible)

# Target mass to deliver to build the colony
M0_TOTAL_MASS = 100_000_000.0  # metric tons (100 million)

# Some plots look better with serif fonts in MCM papers
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 12,
    "axes.titlesize": 14,
    "axes.labelsize": 12,
    "legend.fontsize": 11,
})


# =========================
# 1) Parameters (2.1)
# =========================
@dataclass
class ReliabilityParams:
    # Space elevator
    sway_a: float = 0.85            # eta_sway ~ U(a, 1)
    lambda_e: float = 0.02          # annual failure intensity (Poisson rate)
    repair_years: int = 2           # downtime length if failure occurs
    repair_cost_fixed: float = 0.0  # optional fixed cost per elevator failure (USD)

    # Rockets
    beta: float = 0.02              # per-launch failure probability
    rocket_payload: float = 120.0   # tons per launch (100-150 by problem statement)
    delta_grounding: float = 0.25   # if >=1 accident in a year, reduce remaining capability fractionally
    penalty_cost: float = 0.0       # fixed penalty cost if accident occurs in that year (USD)

    # Accounting choices (important!)
    pay_on_planned_mass: bool = True
    # If True: you pay planned operating cost even if downtime happens (sunk staff/ops)
    # If False: you only pay proportional to delivered mass


# =========================
# 2) Plan (x_t*, y_t*) & cost schedules
# =========================
@dataclass
class AnnualPlan:
    years: np.ndarray                   # year index (0,1,2,...)
    elevator_mass: np.ndarray           # planned mass via elevator in that year (tons)
    rocket_mass: np.ndarray             # planned mass via rockets in that year (tons)
    elevator_cost_per_ton: np.ndarray   # Q(t) USD/ton
    rocket_cost_per_ton: np.ndarray     # P(t) USD/ton


def _canonicalize_col(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[\s\(\)\[\]\{\}]+", "_", s)
    s = re.sub(r"__+", "_", s)
    return s


def _try_find_plan_sheet(xls: pd.ExcelFile) -> Optional[pd.DataFrame]:
    """
    Strategy:
    - Read all sheets
    - Prefer a sheet that contains year + (elevator_mass or rocket_mass) style columns
    - If none found, return None (fallback later)
    """
    best = None
    best_score = -1

    for sh in xls.sheet_names:
        try:
            df = pd.read_excel(xls, sheet_name=sh)
        except Exception:
            continue

        if df is None or df.empty:
            continue

        cols = [_canonicalize_col(c) for c in df.columns.astype(str)]
        score = 0

        # "year" or "t" indicator
        if any(("year" in c) or (c in ["t", "time", "yr"]) for c in cols):
            score += 2

        # elevator / rocket mass indicators
        if any(("elevator" in c or "harbour" in c or "space" in c) and ("mass" in c or "ton" in c) for c in cols):
            score += 2
        if any(("rocket" in c or "launch" in c) and ("mass" in c or "ton" in c) for c in cols):
            score += 2

        # cost indicators
        if any(("q" in c or "elevator" in c) and ("cost" in c or "usd" in c) for c in cols):
            score += 1
        if any(("p" in c or "rocket" in c) and ("cost" in c or "usd" in c) for c in cols):
            score += 1

        if score > best_score:
            best_score = score
            best = df

    # require some minimum evidence
    if best_score >= 3:
        return best
    return None


def _extract_plan_from_df(df: pd.DataFrame) -> Optional[AnnualPlan]:
    """
    Accept flexible column names:
    - year: year / t / time
    - elevator_mass: elevator_mass / space_elevator_mass / harbour_mass / x_t ...
    - rocket_mass: rocket_mass / launches_mass / y_t ...
    - elevator_cost_per_ton: Q / elevator_cost_per_ton / ...
    - rocket_cost_per_ton: P / rocket_cost_per_ton / ...
    """
    if df is None or df.empty:
        return None

    # canonicalize
    orig_cols = list(df.columns.astype(str))
    col_map = {c: _canonicalize_col(c) for c in orig_cols}
    df2 = df.rename(columns=col_map).copy()

    cols = set(df2.columns)

    def pick_col(candidates: List[str]) -> Optional[str]:
        for c in candidates:
            if c in cols:
                return c
        # fuzzy contains
        for c in cols:
            for cand in candidates:
                if cand in c:
                    return c
        return None

    c_year = pick_col(["year", "t", "time", "yr"])
    c_emass = pick_col(["elevator_mass", "space_elevator_mass", "harbour_mass", "x_t", "x"])
    c_rmass = pick_col(["rocket_mass", "launch_mass", "y_t", "y"])
    c_q = pick_col(["elevator_cost_per_ton", "q", "q_t", "elevator_cost", "space_elevator_cost"])
    c_p = pick_col(["rocket_cost_per_ton", "p", "p_t", "rocket_cost"])

    if c_emass is None and c_rmass is None:
        return None

    # year index: if missing, use row index
    if c_year is None:
        years = np.arange(len(df2), dtype=float)
    else:
        years = pd.to_numeric(df2[c_year], errors="coerce").fillna(method="ffill").fillna(0).to_numpy()

        # If year looks like calendar years (e.g., 2050, 2051...), convert to 0-based index
        if np.nanmin(years) >= 1900:
            years = years - np.nanmin(years)

    def to_num(col: Optional[str], default: float) -> np.ndarray:
        if col is None:
            return np.full(len(df2), default, dtype=float)
        return pd.to_numeric(df2[col], errors="coerce").fillna(default).to_numpy(dtype=float)

    elevator_mass = to_num(c_emass, 0.0)
    rocket_mass = to_num(c_rmass, 0.0)

    # cost per ton: if absent, keep NaN for now (we'll fill later)
    q = to_num(c_q, np.nan)
    p = to_num(c_p, np.nan)

    return AnnualPlan(
        years=years.astype(int),
        elevator_mass=elevator_mass,
        rocket_mass=rocket_mass,
        elevator_cost_per_ton=q,
        rocket_cost_per_ton=p,
    )


def _fallback_plan_from_constants(
    scenario: str,
    q_per_ton: float,
    p_per_ton: float,
    elevator_cap: float = 179_000.0,
    rocket_cap: float = 546_000.0,
    hybrid_share_elevator: float = 0.3,
    horizon_years: int = 600,
) -> AnnualPlan:
    """
    Fallback if 参数.xlsx doesn't have a year-by-year plan.
    Uses constant annual capacities, chosen to be consistent with typical deterministic results.

    elevator_cap=179k/yr matches: 100M / 179k ≈ 559 years (as in many baseline solutions).
    rocket_cap default uses 100M / 183 ≈ 546k/yr (commonly derived from sample comparisons).
    """
    years = np.arange(horizon_years, dtype=int)

    if scenario.lower() == "elevator":
        em = np.full(horizon_years, elevator_cap, dtype=float)
        rm = np.zeros(horizon_years, dtype=float)
    elif scenario.lower() == "rocket":
        em = np.zeros(horizon_years, dtype=float)
        rm = np.full(horizon_years, rocket_cap, dtype=float)
    else:  # hybrid
        em = np.full(horizon_years, elevator_cap * hybrid_share_elevator, dtype=float)
        rm = np.full(horizon_years, rocket_cap * (1.0 - hybrid_share_elevator), dtype=float)

    q = np.full(horizon_years, q_per_ton, dtype=float)
    p = np.full(horizon_years, p_per_ton, dtype=float)

    return AnnualPlan(years=years, elevator_mass=em, rocket_mass=rm,
                      elevator_cost_per_ton=q, rocket_cost_per_ton=p)


def load_plans_from_excel(excel_path: str) -> Dict[str, AnnualPlan]:
    """
    Returns dict with keys: "Elevator", "Rocket", "Hybrid"
    Priority:
    1) If excel contains a plan sheet with scenario column => split
    2) Else if excel contains separate sheets => infer each
    3) Else fallback constants (still runnable)
    """
    xls = pd.ExcelFile(excel_path)

    # 1) Try to find a single plan sheet
    df_plan = _try_find_plan_sheet(xls)
    plan = _extract_plan_from_df(df_plan) if df_plan is not None else None

    # Attempt scenario splitting if there's a "scenario" column
    plans: Dict[str, AnnualPlan] = {}

    if df_plan is not None:
        cols_can = [_canonicalize_col(c) for c in df_plan.columns.astype(str)]
        if any("scenario" in c or "strategy" in c or "method" in c for c in cols_can):
            df0 = df_plan.rename(columns={c: _canonicalize_col(c) for c in df_plan.columns.astype(str)})
            scen_col = None
            for c in df0.columns:
                if "scenario" in c or "strategy" in c or "method" in c:
                    scen_col = c
                    break
            if scen_col is not None:
                for key in ["elevator", "rocket", "hybrid"]:
                    sub = df0[df0[scen_col].astype(str).str.lower().str.contains(key)].copy()
                    sub = sub.drop(columns=[scen_col], errors="ignore")
                    ap = _extract_plan_from_df(sub)
                    if ap is not None:
                        name = key.capitalize()
                        plans[name] = ap

    # 2) If not split, try reading per-sheet plans
    if len(plans) == 0:
        for sh in xls.sheet_names:
            try:
                df = pd.read_excel(xls, sheet_name=sh)
            except Exception:
                continue
            ap = _extract_plan_from_df(df)
            if ap is None:
                continue
            sh_l = sh.lower()
            if "elev" in sh_l or "harbour" in sh_l or "tether" in sh_l:
                plans["Elevator"] = ap
            elif "rocket" in sh_l or "launch" in sh_l:
                plans["Rocket"] = ap
            elif "hybrid" in sh_l or "mix" in sh_l or "combined" in sh_l:
                plans["Hybrid"] = ap

    # 3) Fill missing costs if NaN:
    # If you have deterministic totals in the excel (common), we can compute cost/ton.
    # Otherwise use conservative defaults consistent with many baseline comparisons.
    q_default = 4.419e5   # USD/ton (≈44.19T / 100M)
    p_default = 2.080e6   # USD/ton (≈208T / 100M)
    h_default = 1.6345e6  # USD/ton (≈163.45T / 100M) used only if needed

    def fill_costs(ap: AnnualPlan, q_fill: float, p_fill: float) -> AnnualPlan:
        q = ap.elevator_cost_per_ton.copy()
        p = ap.rocket_cost_per_ton.copy()
        q[np.isnan(q)] = q_fill
        p[np.isnan(p)] = p_fill
        return AnnualPlan(ap.years, ap.elevator_mass, ap.rocket_mass, q, p)

    for k in list(plans.keys()):
        if k == "Elevator":
            plans[k] = fill_costs(plans[k], q_default, p_default)
        elif k == "Rocket":
            plans[k] = fill_costs(plans[k], q_default, p_default)
        else:
            plans[k] = fill_costs(plans[k], q_default, p_default)

    # 4) Ensure all three exist; else fallback
    if "Elevator" not in plans:
        plans["Elevator"] = _fallback_plan_from_constants("elevator", q_default, p_default)
    if "Rocket" not in plans:
        plans["Rocket"] = _fallback_plan_from_constants("rocket", q_default, p_default)
    if "Hybrid" not in plans:
        plans["Hybrid"] = _fallback_plan_from_constants("hybrid", q_default, p_default, hybrid_share_elevator=0.30)

    return plans


# =========================
# 3) Monte Carlo Simulation (2.2)
# =========================
def poisson_event_occurs(rng: np.random.Generator, lam: float) -> bool:
    """Annual failure: Poisson(lam) >= 1"""
    if lam <= 0:
        return False
    return rng.poisson(lam) >= 1


def simulate_one_run(
    plan: AnnualPlan,
    params: ReliabilityParams,
    rng: np.random.Generator,
    m0: float = M0_TOTAL_MASS,
    max_years: int = MAX_YEARS
) -> Tuple[int, float]:
    """
    Returns:
      T_years: completion time in years
      C_total: total cost (USD)
    """
    t = 0
    m_cum = 0.0
    c_cum = 0.0

    elevator_down_left = 0  # repair countdown

    # If plan shorter than needed, we repeat the last row
    n_plan = len(plan.years)
    if n_plan == 0:
        raise ValueError("Plan is empty.")

    while m_cum < m0 and t < max_years:
        idx = min(t, n_plan - 1)

        x = float(plan.elevator_mass[idx])
        y = float(plan.rocket_mass[idx])
        q = float(plan.elevator_cost_per_ton[idx])
        p = float(plan.rocket_cost_per_ton[idx])

        # ---- Space Elevator subsystem ----
        elevator_available = 1.0
        if elevator_down_left > 0:
            elevator_available = 0.0
            elevator_down_left -= 1
        else:
            # Poisson annual failure
            if poisson_event_occurs(rng, params.lambda_e):
                elevator_available = 0.0
                elevator_down_left = int(params.repair_years)
                c_cum += float(params.repair_cost_fixed)

        eta_sway = rng.uniform(params.sway_a, 1.0) if elevator_available > 0 else 0.0
        delivered_e = x * eta_sway * elevator_available

        if params.pay_on_planned_mass:
            # pay ops even if downtime; delivered can be 0
            cost_e = x * q
        else:
            cost_e = delivered_e * q

        # ---- Rocket subsystem ----
        payload = max(params.rocket_payload, 1e-9)
        launches = int(math.ceil(y / payload)) if y > 0 else 0

        if launches == 0:
            delivered_r = 0.0
            any_fail = False
        else:
            # successes ~ Binomial(launches, 1-beta)
            successes = rng.binomial(launches, 1.0 - params.beta)
            any_fail = successes < launches

            delivered_r = successes * payload
            delivered_r = min(delivered_r, y)  # cannot exceed planned

            # grounding penalty: if any accident, lose delta fraction of annual capability
            if any_fail:
                delivered_r *= (1.0 - params.delta_grounding)
                c_cum += float(params.penalty_cost)

        if params.pay_on_planned_mass:
            cost_r = y * p
        else:
            cost_r = delivered_r * p

        # ---- Update totals ----
        m_cum += delivered_e + delivered_r
        c_cum += cost_e + cost_r

        t += 1

    return t, c_cum


def run_monte_carlo(
    plan: AnnualPlan,
    params: ReliabilityParams,
    n_sim: int = N_SIM,
    seed: int = RNG_SEED
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    T = np.zeros(n_sim, dtype=int)
    C = np.zeros(n_sim, dtype=float)

    for i in range(n_sim):
        Ti, Ci = simulate_one_run(plan, params, rng)
        T[i] = Ti
        C[i] = Ci

    return pd.DataFrame({"T_years": T, "C_total_USD": C})


# =========================
# 4) Summary Stats
# =========================
def summarize_samples(df: pd.DataFrame, deadline_years: Optional[float] = None) -> Dict[str, float]:
    T = df["T_years"].to_numpy(dtype=float)
    C = df["C_total_USD"].to_numpy(dtype=float)

    def ci95(x: np.ndarray) -> Tuple[float, float]:
        lo, hi = np.percentile(x, [2.5, 97.5])
        return float(lo), float(hi)

    out = {}
    out["T_mean"] = float(np.mean(T))
    out["T_std"] = float(np.std(T, ddof=1))
    out["T_ci95_lo"], out["T_ci95_hi"] = ci95(T)
    out["T_p90"] = float(np.percentile(T, 90))
    out["T_p95"] = float(np.percentile(T, 95))

    out["C_mean_USD"] = float(np.mean(C))
    out["C_std_USD"] = float(np.std(C, ddof=1))
    out["C_ci95_lo_USD"], out["C_ci95_hi_USD"] = ci95(C)
    out["C_p90_USD"] = float(np.percentile(C, 90))
    out["C_p95_USD"] = float(np.percentile(C, 95))

    if deadline_years is not None:
        out["P(T > deadline)"] = float(np.mean(T > deadline_years))

    return out


# =========================
# 5) Publication-ready plots (pastel)
# =========================
PASTEL = {
    "Elevator": "#9ecae1",  # light blue
    "Rocket":   "#fdae6b",  # light orange
    "Hybrid":   "#a1d99b",  # light green
}

def _style_axes(ax):
    ax.grid(True, which="major", linestyle="--", linewidth=0.6, alpha=0.35)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

def plot_histograms(all_samples: Dict[str, pd.DataFrame]):
    # Completion time histogram
    fig, ax = plt.subplots(figsize=(8.6, 5.2))
    for name, df in all_samples.items():
        ax.hist(df["T_years"], bins=40, density=True, alpha=0.35, label=name, color=PASTEL.get(name, None))
    ax.set_xlabel("Completion Time (years)")
    ax.set_ylabel("Density")
    _style_axes(ax)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "fig_T_hist.png"), dpi=300)
    plt.close(fig)

    # Cost histogram (convert to trillion for readability)
    fig, ax = plt.subplots(figsize=(8.6, 5.2))
    for name, df in all_samples.items():
        ax.hist(df["C_total_USD"] / 1e12, bins=40, density=True, alpha=0.35, label=name, color=PASTEL.get(name, None))
    ax.set_xlabel("Total Cost (trillion USD)")
    ax.set_ylabel("Density")
    _style_axes(ax)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "fig_C_hist.png"), dpi=300)
    plt.close(fig)

def plot_ecdf(all_samples: Dict[str, pd.DataFrame]):
    fig, ax = plt.subplots(figsize=(8.6, 5.2))
    for name, df in all_samples.items():
        x = np.sort(df["T_years"].to_numpy())
        y = np.arange(1, len(x) + 1) / len(x)
        ax.plot(x, y, linewidth=2.0, label=name, color=PASTEL.get(name, None))
    ax.set_xlabel("Completion Time (years)")
    ax.set_ylabel("ECDF")
    _style_axes(ax)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "fig_T_ecdf.png"), dpi=300)
    plt.close(fig)

def plot_cost_time_scatter(all_samples: Dict[str, pd.DataFrame]):
    fig, ax = plt.subplots(figsize=(8.6, 5.2))
    for name, df in all_samples.items():
        ax.scatter(df["T_years"], df["C_total_USD"] / 1e12,
                   s=10, alpha=0.18, label=name, color=PASTEL.get(name, None), edgecolors="none")
    ax.set_xlabel("Completion Time (years)")
    ax.set_ylabel("Total Cost (trillion USD)")
    _style_axes(ax)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "fig_cost_time_scatter.png"), dpi=300)
    plt.close(fig)


# =========================
# 6) Main
# =========================
def main():
    print("Loading plans from Excel:", EXCEL_PATH)
    plans = load_plans_from_excel(EXCEL_PATH)

    # --- Reliability parameter set (edit to match your paper choices) ---
    # These default values follow your docx structure:
    # eta_sway ~ U(a, 1), elevator failures via Poisson(lambda_E), repair lasts k years
    # rocket failures per launch ~ Bernoulli(beta), with grounding penalty delta
    params = ReliabilityParams(
        sway_a=0.85,
        lambda_e=0.02,
        repair_years=2,
        repair_cost_fixed=0.0,
        beta=0.02,
        rocket_payload=120.0,
        delta_grounding=0.25,
        penalty_cost=0.0,
        pay_on_planned_mass=True,
    )

    all_samples: Dict[str, pd.DataFrame] = {}
    summary_rows = []

    for name in ["Elevator", "Rocket", "Hybrid"]:
        print(f"Running Monte Carlo for: {name}")
        df = run_monte_carlo(plans[name], params, n_sim=N_SIM, seed=RNG_SEED + hash(name) % 10000)
        df["Scenario"] = name
        all_samples[name] = df

        stats = summarize_samples(df, deadline_years=None)
        stats["Scenario"] = name
        summary_rows.append(stats)

    # Save samples
    samples_all = pd.concat(all_samples.values(), ignore_index=True)
    samples_path = os.path.join(OUT_DIR, "problem2_mc_samples.csv")
    samples_all.to_csv(samples_path, index=False)
    print("Saved samples to:", samples_path)

    # Save summary
    summary_df = pd.DataFrame(summary_rows)
    summary_path = os.path.join(OUT_DIR, "problem2_mc_summary.csv")
    summary_df.to_csv(summary_path, index=False)
    print("Saved summary to:", summary_path)

    # Print key results
    with pd.option_context("display.max_columns", 200):
        print("\n=== Monte Carlo Summary (key columns) ===")
        show_cols = [
            "Scenario",
            "T_mean", "T_ci95_lo", "T_ci95_hi", "T_p95",
            "C_mean_USD", "C_ci95_lo_USD", "C_ci95_hi_USD", "C_p95_USD"
        ]
        cols_exist = [c for c in show_cols if c in summary_df.columns]
        print(summary_df[cols_exist])

    # Plots
    print("Generating figures...")
    plot_histograms(all_samples)
    plot_ecdf(all_samples)
    plot_cost_time_scatter(all_samples)
    print("Figures saved to:", OUT_DIR)
    print("Done.")


if __name__ == "__main__":
    main()
